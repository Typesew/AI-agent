"""LLM-экстракция узлов и связей по жёсткой схеме (Ollama + Qwen3).

    python -m indexing.extract_llm                     # все документы
    python -m indexing.extract_llm --only sever_credit # один документ
    python -m indexing.build_graph --source llm        # затем загрузить в граф
    python -m eval.eval_extraction                     # и сравнить с эталоном

Глоссарий (термины и события) пишется руками и копируется из эталона: это
справочник, к которому LLM привязывает условия, а не предмет экстракции.
"""

import argparse
import json
import re
import shutil
from pathlib import Path

from indexing.chunk import all_docs, chunk_doc, parse_doc
from indexing.schema import EXTRACTED_LABELS, REL_TYPES
from rag import llm

ROOT = Path(__file__).resolve().parent.parent
GOLD_DIR = ROOT / "data" / "extracted" / "gold"
OUT_DIR = ROOT / "data" / "extracted" / "llm"

SCHEMA = {
    "type": "object",
    "properties": {
        "nodes": {"type": "array", "items": {"type": "object", "properties": {
            "id": {"type": "string"},
            "label": {"type": "string", "enum": EXTRACTED_LABELS},
            "name": {"type": "string"},
            "value": {"type": "string"},
            "section": {"type": "string"},
        }, "required": ["id", "label", "name", "value", "section"]}},
        "edges": {"type": "array", "items": {"type": "object", "properties": {
            "type": {"type": "string", "enum": list(REL_TYPES)},
            "from": {"type": "string"},
            "to": {"type": "string"},
            "section": {"type": "string"},
        }, "required": ["type", "from", "to", "section"]}},
    },
    "required": ["nodes", "edges"],
}

PROMPT = """Извлеки из фрагмента банковского документа граф знаний строго по схеме.

Создавай только узлы:
- Condition — условие продукта (лимит, ставка, льготный период, кешбэк, минимальный платёж, срок);
- Fee — платёж клиента (обслуживание, комиссия, штраф, неустойка);
- Exception — исключение из условия (на что условие не распространяется), один узел на каждый пункт перечня.
name — короткое название, value — суть с числами как в тексте, section — номер пункта (например "2.2").

Допустимые связи (from -> to):
{rels}

Уже существующие узлы, ссылайся на них по id и не создавай заново:
- продукт: {product_id} ({product})
- термины (Term): {terms}
- события (Event): {events}
- узлы из предыдущих разделов этого документа: {previous}

Каждое Condition и Fee свяжи с подходящим термином через DEFINED_AS, если такой есть.
Если событие из списка отменяет условие — CANCELS, если включает штраф или новую ставку — TRIGGERS.
Каждое Exception свяжи с условием через HAS_EXCEPTION, а с событием, о котором оно, — через APPLIES_TO
(«снятие сверх лимита» — это событие превышения лимита, а не снятия наличных).
Ничего не выдумывай: только то, что прямо написано во фрагменте.

Фрагмент:
{text}"""


# Чтобы промпт не раздувался, в нём только термины и события, уместные для типа продукта.
DOC_TYPE_TERMS = {
    "credit_card": ["term_grace", "term_psk", "term_minpay", "term_cash_withdrawal", "term_cc_transfer", "term_penalty",
                    "term_fine", "term_credit_limit", "term_grace_extension", "term_subscription", "term_rate",
                    "term_service_fee", "term_cashback", "term_btn_installment", "term_promo"],
    "installment": ["term_installment", "term_bnpl", "term_btn_installment", "term_penalty", "term_fine", "term_rate",
                    "term_early", "term_credit_history", "term_mfo", "term_overdue", "term_service_fee",
                    "term_credit_limit", "term_grace", "term_minpay", "term_cc_transfer", "term_subscription"],
    "debit_card": ["term_service_fee", "term_cash_withdrawal", "term_cashback", "term_cashback_limit",
                   "term_subscription", "term_balance_interest", "term_sbp", "term_loyalty", "term_promo"],
}
DOC_TYPE_TERMS["student_card"] = DOC_TYPE_TERMS["debit_card"] + ["term_student_card"]
DOC_TYPE_EVENTS = {
    "credit_card": ["ev_missed_payment", "ev_not_full_repay", "ev_cash", "ev_transfer", "ev_paid_service",
                    "ev_promo_end", "ev_limit_exceeded"],
    "installment": ["ev_missed_payment", "ev_missed_two", "ev_paid_service"],
    "debit_card": ["ev_low_spend", "ev_paid_service", "ev_promo_end", "ev_limit_exceeded", "ev_cash", "ev_transfer"],
    "student_card": ["ev_student_lost", "ev_low_spend", "ev_cash", "ev_transfer"],
}
SKIP_TYPES = {"glossary", "regulatory", "case"}


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9а-я]+", "_", text.lower()).strip("_")


def extract_doc(path: Path, catalog: dict[str, dict], model: str) -> dict:
    meta, _ = parse_doc(path)
    pid = meta["doc_id"]
    rels = "\n".join(f"- {r}: " + ", ".join(f"{a} -> {b}" for a, b in pairs) for r, pairs in REL_TYPES.items()
                     if r not in ("OFFERED_BY",))
    terms = ", ".join(f"{i} ({catalog[i]['name']})" for i in DOC_TYPE_TERMS[meta["doc_type"]])
    events = ", ".join(f"{i} ({catalog[i]['name']})" for i in DOC_TYPE_EVENTS[meta["doc_type"]])

    nodes, edges = [], []
    for chunk in chunk_doc(path):
        previous = ", ".join(f"{n['id']} ({n['name']})" for n in nodes) or "нет"
        prompt = PROMPT.format(rels=rels, product_id=pid, product=meta["product"], terms=terms, events=events,
                               previous=previous, text=chunk["text"])
        raw = llm.chat([{"role": "user", "content": prompt}], model=model, schema=SCHEMA)
        data = json.loads(raw)
        # id от LLM делаем уникальными в рамках документа, ссылки на справочник не трогаем
        remap = {}
        for n in data["nodes"]:
            new_id = f"{pid}__{_slug(n['id'])}"
            remap[n["id"]] = new_id
            nodes.append({**n, "id": new_id, "aliases": ""})
        for e in data["edges"]:
            edges.append([e["type"], remap.get(e["from"], e["from"]), remap.get(e["to"], e["to"]), e.get("section", "")])
        print(f"  {chunk['id']}: узлов {len(data['nodes'])}, связей {len(data['edges'])}")
    return {"nodes": nodes, "edges": edges}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=llm.DEFAULT_MODEL)
    parser.add_argument("--only", help="doc_id одного документа")
    args = parser.parse_args()
    if not llm.available():
        parser.error(f"Ollama недоступен по {llm.OLLAMA_URL}")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy(GOLD_DIR / "glossary.json", OUT_DIR / "glossary.json")
    glossary = json.loads((GOLD_DIR / "glossary.json").read_text(encoding="utf-8"))
    catalog = {n["id"]: n for n in glossary["nodes"]}

    for path in all_docs():
        meta, _ = parse_doc(path)
        if meta["doc_type"] in SKIP_TYPES or (args.only and meta["doc_id"] != args.only):
            continue
        print(f"{meta['doc_id']} ({args.model})")
        result = extract_doc(path, catalog, args.model)
        (OUT_DIR / f"{meta['doc_id']}.json").write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
