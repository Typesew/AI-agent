"""Обогащённый промпт и разбор ответа.

В промпт идут фрагменты [c1]…, факты графа [f1]… и результаты инструментов [t1]….
Модель не ставит ссылки в тексте, а в последней строке пишет «ИСПОЛЬЗОВАНО: c1,f3»;
код вырезает строку и сам собирает единый блок «Источники» только по этим id.
Если строки нет или id неверные — показываем все источники контекста.
"""

import json
import re
from dataclasses import dataclass

from rag.retriever import Context

SYSTEM = """Ты «Банковский переводчик»: объясняешь условия банковских карт, кредитов и рассрочек простым языком.

Правила:
1. Отвечай только по контексту. Не придумывай ставки, суммы, сроки и даты.
2. Числа расчётов бери только из результатов инструментов [t…], сам ничего не считай.
3. Если в контексте нет ответа, напиши ровно: «В корпусе нет данных по этому вопросу.»
4. Структура ответа — разделы «**Плюсы**», «**Минусы**», «**Подводные камни**», «**Итог**».
   Для вопроса-определения или чистого расчёта можно короче: только нужные разделы, пустых не пиши.
5. Не ставь ссылки в тексте. Последней строкой напиши id использованных фрагментов:
   ИСПОЛЬЗОВАНО: c1,f2,t1"""

USED_RE = re.compile(r"^\s*ИСПОЛЬЗОВАНО\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)


@dataclass
class Source:
    file: str
    section: str
    date: str
    title: str

    def render(self) -> str:
        return f"{self.title} — {self.file}, {self.section}, ред. {self.date}"


def context_items(ctx: Context, tool_results: list[dict] | None = None) -> dict[str, tuple[str, Source | None]]:
    """id -> (текст для промпта, источник)."""
    items: dict[str, tuple[str, Source | None]] = {}
    for i, c in enumerate(ctx.chunks, 1):
        m = c.metadata
        title = f"«{m['product']}» ({m['bank']})" if m.get("product", "-") != "-" else c.text.splitlines()[0]
        items[f"c{i}"] = (c.text, Source(m["source_file"], f"раздел {m['section']}", m["date"], title))
    for i, f in enumerate(ctx.facts, 1):
        src = f.source
        items[f"f{i}"] = (f.text, Source(src["file"], f"п. {src['section']}", src["date"], f.product) if src else None)
    for i, t in enumerate(tool_results or [], 1):
        items[f"t{i}"] = (f"{t['tool']}({json.dumps(t['args'], ensure_ascii=False)}) = "
                          f"{json.dumps(t['result'], ensure_ascii=False)}", None)
    return items


def build_messages(question: str, ctx: Context, tool_results: list[dict] | None = None) -> list[dict]:
    items = context_items(ctx, tool_results)
    body = "\n\n".join(f"[{k}] {text}" for k, (text, _) in items.items()) or "(контекст пуст)"
    if ctx.table:
        body += "\n\nСравнение из графа:\n" + ctx.table
    return [{"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"Контекст:\n{body}\n\nВопрос: {question}"}]


def parse_answer(text: str, items: dict) -> tuple[str, list[str], bool]:
    """(ответ без служебной строки, использованные id, удалось ли их разобрать)."""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    matches = list(USED_RE.finditer(text))
    if not matches:
        return text, list(items), False
    last = matches[-1]
    body = (text[:last.start()] + text[last.end():]).strip()
    ids = [i.strip().strip("[]").lower() for i in re.split(r"[,\s;]+", last.group(1)) if i.strip()]
    valid = [i for i in ids if i in items]
    if not valid:
        return body, list(items), False
    return body, valid, True


def collect_sources(used: list[str], items: dict) -> list[Source]:
    seen, out = set(), []
    for i in used:
        src = items.get(i, (None, None))[1]
        if src and (src.file, src.section) not in seen:
            seen.add((src.file, src.section))
            out.append(src)
    return out
